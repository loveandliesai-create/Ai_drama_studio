AI Creator Studio - clickable prototype
Open index.html in a browser to test the app screens.
This prototype contains Home, Create AI Video, Create AI Music, and My Creations.
The generation buttons are placeholders; real AI generation APIs must be connected next.
