# AI Drama Studio V2 — Real AI

This version connects the website to an AI model through a Python backend.

## Important
Do NOT put your API key inside `app.js` or `index.html`. The key belongs on the server as an environment variable.

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Set your API key:
   - Windows PowerShell: `$env:OPENAI_API_KEY="YOUR_KEY"`
   - macOS/Linux: `export OPENAI_API_KEY="YOUR_KEY"`
5. Run: `python server.py`
6. Open `http://localhost:8000`

## Deploy
Deploy the folder to a Python-capable host. Add `OPENAI_API_KEY` as a secret/environment variable in the hosting dashboard. Do not commit `.env` or expose the key to the browser.

## What V2 does
- Sends the user's story idea to the AI model.
- Generates an original title and logline.
- Creates consistent character profiles.
- Creates scene-by-scene action and dialogue.
- Creates visual prompts for each character and scene.
- Allows downloading the generated result as JSON.

## Next upgrades
- Generate actual character images.
- Generate scene images.
- Text-to-speech dialogue.
- Image-to-video animation.
- User accounts and saved projects.
- Usage limits/payments.
