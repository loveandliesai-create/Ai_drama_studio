import os, json
from flask import Flask, request, jsonify, send_from_directory
from openai import OpenAI

app = Flask(__name__, static_folder=".", static_url_path="")
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

SYSTEM = """You are a professional short-form drama writer. Create original, emotionally engaging 1-3 minute social-media drama episodes.
Return ONLY valid JSON with this shape:
{"title":"...","logline":"...","characters":[{"name":"...","role":"...","description":"...","visual_prompt":"..."}],"scenes":[{"title":"...","action":"...","dialogue":"...","visual_prompt":"...","camera":"..."}]}
Make 3-5 memorable characters and 5-9 scenes depending on requested length. Keep dialogue concise enough for the requested runtime.
Visual prompts must describe the same characters consistently, including age range, hair, clothing, setting, lighting and cinematic style. Avoid copyrighted characters or existing movie plots. Do not include markdown fences."""

@app.get("/")
def home(): return send_from_directory(".", "index.html")

@app.post("/api/generate")
def generate():
    data=request.get_json(silent=True) or {}
    idea=str(data.get("idea","")).strip()
    genre=str(data.get("genre","Romance & Drama"))
    length=str(data.get("length","2 minutes"))
    if not idea: return jsonify(error="Story idea is required."),400
    prompt=f"""Create a {length} {genre} episode from this idea:
{idea}
Make it suitable for TikTok, Instagram Reels, Facebook Reels and YouTube Shorts."""
    try:
        response=client.responses.create(
            model=os.environ.get("OPENAI_MODEL","gpt-6-luna"),
            instructions=SYSTEM,
            input=prompt
        )
        text=response.output_text.strip()
        if text.startswith("```"):
            text=text.replace("```json","").replace("```","").strip()
        return jsonify(json.loads(text))
    except Exception as e:
        return jsonify(error="AI generation failed. Check your API key/server setup."),500

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",8000)))
