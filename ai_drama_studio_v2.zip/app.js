let lastResult=null;
async function generate(){
 const idea=document.getElementById("idea").value.trim();
 if(!idea){alert("Please enter your story idea.");return}
 const btn=document.getElementById("go"), status=document.getElementById("status");
 btn.disabled=true; status.textContent="Creating your drama...";
 document.getElementById("output").classList.add("hidden");
 try{
  const r=await fetch("/api/generate",{method:"POST",headers:{"Content-Type":"application/json"},
   body:JSON.stringify({idea,genre:document.getElementById("genre").value,length:document.getElementById("length").value})});
  const data=await r.json(); if(!r.ok) throw new Error(data.error||"Generation failed");
  lastResult=data; render(data); status.textContent="Done!";
 }catch(e){status.textContent=e.message;status.classList.add("error")}
 finally{btn.disabled=false}
}
function render(d){
 document.getElementById("title").textContent=d.title||"Untitled Episode";
 document.getElementById("logline").textContent=d.logline||"";
 const chars=(d.characters||[]).map(c=>`<div class="card"><h3>${esc(c.name)}</h3><p><b>Role:</b> ${esc(c.role)}</p><p>${esc(c.description)}</p><p><b>Visual prompt:</b> ${esc(c.visual_prompt)}</p></div>`).join("");
 const scenes=(d.scenes||[]).map((s,i)=>`<div class="scene"><h4>Scene ${i+1}: ${esc(s.title)}</h4><p><b>Action:</b> ${esc(s.action)}</p><p><b>Dialogue:</b> ${esc(s.dialogue)}</p><p><b>Visual prompt:</b> ${esc(s.visual_prompt)}</p><p><b>Camera:</b> ${esc(s.camera)}</p></div>`).join("");
 document.getElementById("content").innerHTML=`<div class="card"><h3>Characters</h3>${chars}</div><div class="card"><h3>Scenes</h3>${scenes}</div>`;
 document.getElementById("output").classList.remove("hidden");document.getElementById("output").scrollIntoView({behavior:"smooth"});
}
function esc(x){return String(x??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[m]))}
function download(){if(!lastResult)return;const b=new Blob([JSON.stringify(lastResult,null,2)],{type:"application/json"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download="ai-drama.json";a.click();URL.revokeObjectURL(a.href)}
